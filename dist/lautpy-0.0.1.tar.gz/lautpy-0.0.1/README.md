

<h1 align = "center">:rocket: 常用工具类 :facepunch:</h1>

## Install
```bash
pip install -U lautpy
```

## 

### Tools
```python
from lautpy.pipe import *

for i in range(5) | xtqdm:
    logger.info("这是一个进度条")

with timer('LOG'):
    logger.info("打印一条log所花费的时间")
```

<details>
  <summary><b>A</b></summary>
  a.b
</details>


### Notice
```python
from lautpy.pipe import *

for i in range(5) | xtqdm:
    logger.info("这是一个进度条")

with timer('LOG'):
    logger.info("打印一条log所花费的时间")
```

---
## TODO

